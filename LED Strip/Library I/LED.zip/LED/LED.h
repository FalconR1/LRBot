#include <Adafruit_NeoPixel.h>

#define LED_PIN    5
#define LED_COUNT 10

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

uint32_t red = strip.Color(255, 0, 0);
uint32_t blue = strip.Color(39, 167, 216);
uint32_t orange = strip.Color(255, 109, 10);

void forward(){
  for(int p=LED_COUNT+1; p>-2; p--){  
      strip.setBrightness(255);
      strip.setPixelColor(p, red);
      strip.setPixelColor(p-1, red);
      strip.setPixelColor(p-2, red);
      strip.show();
      delay(100);
      strip.clear();
      strip.show();
  }
}

void back(){
  for(int p=-1; p<LED_COUNT; p++){
      strip.setBrightness(255);
      strip.setPixelColor(p, red);
      strip.setPixelColor(p+1, red);
      strip.setPixelColor(p+2, red);
      strip.show();
      delay(100);
      strip.clear();
      strip.show();
  }
}
 
void fill(){
  strip.setBrightness(255);
  strip.fill(red, 0, LED_COUNT);
  strip.show();
}

void fade(){
  while(true){
      for(int i=0; i<256; i+=16){
        strip.setBrightness(i);
        strip.fill(red, 0, LED_COUNT);
        strip.show();
      }
      delay(80);
      for(int i=256; i>0; i-=16){
        strip.setBrightness(i);
        strip.fill(red, 0, LED_COUNT);
        strip.show();
      }
      delay(80);
  }
}